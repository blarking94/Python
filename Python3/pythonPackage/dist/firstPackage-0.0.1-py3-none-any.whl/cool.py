
def print_this():
	print("This is cool!")